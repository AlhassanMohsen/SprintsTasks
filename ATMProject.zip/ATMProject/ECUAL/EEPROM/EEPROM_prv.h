/*
 * EEPROM_prv.h
 *
 *  Created on: Jan 27, 2022
 *      Author: Alhassan Mohsen
 */

#ifndef ECUAL_EEPROM_EEPROM_PRV_H_
#define ECUAL_EEPROM_EEPROM_PRV_H_

#define EEPROM_CONTROL_BYTE_HIGH_NIBBLE_MASK			0b10100000
#define EEPROM_FIRST_CHIP_SELECT_BIT					1
#define EEPROM_RW_CONTROL_WRITE							0x00
#endif /* ECUAL_EEPROM_EEPROM_PRV_H_ */
